Rescue - Version 1.3
Gato D, Copyright 2015
---
OVERVIEW
The riveting story of a groundhog who has to climb and throw rocks at stuff to save a mouse from a pterodactyle pirate robot thing.
A short, early '80s arcade-styled platformer with 8 levels.

CONTROLS
Arrow keys - Move and climb ladders
Z - Jump
X - Throw a rock
P - Pause

NOTICE FOR WINDOWS USERS
If you try to run the game and it doesn't work, check your antivirus isn't detecting the game as suspicious activity.

--

Changelog

v1.3
* The adventure mode got a total overhaul! 4 new levels bringing the total count to 12. There's some challenging levels ahead on your adventure now!
* The bear on level 5 and their rocks now have predictable patterns.
* Fixed some memory leaks

v1.2
* Added an intro cutscene to the Adventure Mode
* Several small fixes

v1.1
* Added an adventure mode that let's you play the game without a lives/scoring system
* Fixed some bugs

v1.0
* Initial release