                                      `-:/++++/:-.``                            
   Medic Panic!                      mNNNNNNNNNNMNNNmdhso/.`                    
   Early Preview - 04/20/15          NNNNNNNNNNNNNNNNNNNNNdo:`                
   Controls:                         NNNNNds+/:/oymNNNNNNNNNNNNms-              
    > Move with arrow keys           NNd/.      `-sNNNNNNNNNNNNNNy`            
    > Jump with Z                    MNd:`         `/mNNNNNNNNNNNNNm-           
    > Heal infected patients with X  NMo.           .oNNNNNNNNNNNNNMd`          
    > Use powerups with C            NM+`            :mNNNNNNNNNNNNNM/          
    > Exit the game with Escape      NMo`            -hNNNNNNNNNNNNNMy          
    > Pause it with P                NNd-            :mNNNNNNNNNNNNNMy          
                                     Ndh+.          .sNNNNNNNNNNNNNNM+          
        /NNNNNNNNNNNNNNNNNNNNNNNNmds+/:::/:`      `-/ohdNNNNNNNNNNNNN.          
                                     yhdmmmho////+ymNNmdmNNNNNNNNNNM+           
    Please answer the form attached  NNNNNNNNNNNNNNNNNNNNNNNNNNNNNMy`           
    to the game after playing!       NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNy.          
                                     NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNm+`        
    Have fun!                        NNNNNNNNNNNNNNmNNNNmmmNNNNNNNNNNNNy.       
                                     NNNmNNNmhhsso+:yds+///+smNNNNNNNNNMd.      
    -dNNNNNNNNNNNNNNNNNNNNmmmddhhsmNmho+///os::::::://:::::::+NNNNNNNNNNMy`     
   .mMNNNNNNNNNNNNNNNNNs+////:::::ho/:---:::/:::::::::o+-``.::+NNNNNNNNNNN.     
   yMNNNNNNNNNNNNNNNNNN+::::::::::::.`   `-::::::::::/m+:/. `::hNNNNNNNNNd`     
  -NNNNNNNNNNNNNNNNNNNNd/::::::::::`   .ss-.:::::::::yd+NMd. .::mNNNNNNNMo      
  oMNNNNNNNNNNNNNNNNNNNNms/::::::::   `hMMd.-::::::::myhMMMo -syhNNNNNNMm.      
 .mMNNNNNNNNNNNNNNNNNNNNNNd+:::::::   .mMMM/.::::::::hdyMMMdyys///yNNNNM+       
 -MMNNNNNNNNNNNmddddmNNNNNNN+::::::`  `dMMN:.::::::::/syhys+/::::::oNNMd`       
 -NMNNNNNNNNNdo//:://+yNNNNMo:::::h:   -sho`-::::::::::::::::::::::/NNM/        
 `hMNNNNNNNNm:::///::::+mNNm/:::::hh:`    `.::::::::::::::::::::::/hhoNy        
  :NNNNNNNNMy::://o+/:::sNd+::::::/shs:---::::::::::::///:::////oyhs::mm.       
   oNNNNNNNNd:::/+//+:::/+/:::::::::/+::::::::::::::::oydhyyyhhys+/:::mm.       
   `oNNNNNNNNy//::::+/:::::::::::::::::::::::::::::::::sm+:::::::::::hNo        
     :dNNNNNNNNdhyso/::::::::::::::::::::::::::::::::::hd/:::::::::+dN+`        
      `/dNNNNNNNNNNNms/:::::::::::::::::::///////::::::/dd/:::::/ohmy-          
     `.``:sdNNNNNNNNNNd+:::::::::::::::::yhysssyhyyyyyyhy+:/+yhdNmo-            
    :mNds:.-sMNNNNNNNNNNy+/::::::::::::::/::::::://ymo/::+ymNNNMMmdyo`          
    +MNNNNNmNNNNNNNNNNNNNNdy+//:::::::::::::::::::::+s::yNNNNNNNNNNMN:          
    -NNNNNNNNNNNNNNNNNNNNNNNNmy:/++///:::::::::::::::::+dmmNNNNNNNd+.           
     sNNNNNNNNNNNNNNNNNNNmmy+:` hdddddy+/:::::::::::::. `..-/smNNo.             
     `/dNNNNNNNNNNNmddyo/-`     oNddddddhs+++///////s.        `-sdmy:`          
       `-+shmMNh:--.`           `hNmdddddddhysoooooohs           `:smd+`        
           .dN+                  `+mNdddddddddddhhdddd-             `+md:       
           sM+                     -dNNddddddddddddddms               -dN+      
          :Nh                       `yNNmddddddddddddmd`               .hN/     
         `dN-                        `sNNNNmmdddddddmNd`                .mm-    
         /Mh                          `sNNNNNNNmmmNNNNd`                 /Mh    
         hN:                           `yNNNNNNNNNNNNNd`                 `hM/   
        -Nd`                            `dNNNNNNNNNNNNd`                  :Mh   
        +Mo                              -NNNNNNNNNNNNh                   `hN-  
       `hN-                               oNNNNNNNNNNNs                    +Ms  
       .md`                               `yNNNNNNNNNNs                    .Nm  
       /Mh`................................-mNNNNNNNNM+`....................dM+ 
       .yNmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmNNNNNNNNNmmmmmmmmmmmmmmmmmmmmmmms. 
                                                                               