Speedster - Version 1.2
Gato D, Copyright 2015
---
OVERVIEW
Speedster is an arcade driving game inspired by Taito's Super Speed Race. Since the original game is rather obscure and it's not well emulated, I decided to make one to play myself.

CONTROLS
Mouse - Move
Left Click/Z - Accelerate
Right Click/Spacebar - Change Gear

NOTICE FOR OSX USERS
If you try to run the game and it doesn't work, check if you have the option to run apps from unidentified developers enabled on System Preferences > Security.