Rescue - Version 1.1
Gato D, Copyright 2015
---
OVERVIEW
The riveting story of a groundhog who has to climb and throw rocks at stuff to save a mouse from a pterodactyle pirate robot thing.
A short, early '80s arcade-styled platformer with 8 levels.

CONTROLS
Arrow keys - Move and climb ladders
Z - Jump
X - Throw a rock
P - Pause

NOTICE FOR OSX USERS
If you try to run the game and it doesn't work, check if you have the option to run apps from unidentified developers enabled on System Preferences > Security.