Speedster - Version 1.2
Gato D, Copyright 2015
---
OVERVIEW
Speedster is an arcade driving game inspired by Taito's Super Speed Race. Since the original game is rather obscure and it's not well emulated, I decided to make one to play myself.

CONTROLS
Mouse - Move
Left Click/Z - Accelerate
Right Click/Spacebar - Change Gear

NOTICE FOR WINDOWS USERS
If you try to run the game and it doesn't work, check your antivirus isn't detecting the game as suspicious activity.