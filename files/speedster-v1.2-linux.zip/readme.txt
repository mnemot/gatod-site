Speedster - Version 1.2
Gato D, Copyright 2015
---
OVERVIEW
Speedster is an arcade driving game inspired by Taito's Super Speed Race. Since the original game is rather obscure and it's not well emulated, I decided to make one to play myself.

CONTROLS
Mouse - Move
Left Click/Z - Accelerate
Right Click/Spacebar - Change Gear

NOTICE FOR LINUX USERS
If you try to run the game and it doesn't work, you should install some dependencies.
The corresponding command on Ubuntu and other Debian based systems is:
$ sudo apt-get install zlib1g lib32z1 libbz2-1.0:i386 lib32ncurses5 libxxf86vm1 libgl1-mesa-glx:i386 libglu1-mesa:i386 libopenal1:i386 libssl1.0.0:i386
Also, check that the runner is actually set as executable. The install.sh batch file that comes with the game does that, alongside creating a .desktop file to launch the game easily.