Rescue - Version 1.1
Gato D, Copyright 2015
---
OVERVIEW
The riveting story of a groundhog who has to climb and throw rocks at stuff to save a mouse from a pterodactyle pirate robot thing.
A short, early '80s arcade-styled platformer with 8 levels.

CONTROLS
Arrow keys - Move and climb ladders
Z - Jump
X - Throw a rock
P - Pause

NOTICE FOR LINUX USERS
If you try to run the game and it doesn't work, you should install some dependencies.
The corresponding command on Ubuntu and other Debian based systems is:
$ sudo apt-get install zlib1g lib32z1 libbz2-1.0:i386 lib32ncurses5 libxxf86vm1 libgl1-mesa-glx:i386 libglu1-mesa:i386 libopenal1:i386 libssl1.0.0:i386
Also, check that the runner is actually set as executable. The install.sh batch file that comes with the game does that, alongside creating a .desktop file to launch the game easily.