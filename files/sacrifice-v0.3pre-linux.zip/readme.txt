 _____  ___  _____ ______ ___________ _____ _____  _____ 
/  ___|/ _ \/  __ \| ___ \_   _|  ___|_   _/  __ \|  ___|
\ `--./ /_\ \ /  \/| |_/ / | | | |_    | | | /  \/| |__  
 `--. \  _  | |    |    /  | | |  _|   | | | |    |  __| 
/\__/ / | | | \__/\| |\ \ _| |_| |    _| |_| \__/\| |___ 
\____/\_| |_/\____/\_| \_|\___/\_|    \___/ \____/\____/ 
Version 0.3pre - Do not distribute!
---
Face the wrath of the udnerground beast's maze full of traps and foes.
10 levels, two weapons, save/load system.
Still a WIP, though!
---
Default keyboard keys:

> Arrows: Move, climb
> Z: Jump
> X: Shoot
> A/S: Switch weapon
> P: Pause
---
Default joysitck buttons:
> DPad: Mode, climb
> 1 (Face button U): Jump
> 2 (Face button R): Shoot
> 5/6 (Shoulder Buttons): Switch weapon
> 10 (Start): Pause
---
Default gamepad buttons:
> DPad: Move, climb
> X: Shoot
> A: Jump
> Shoulder buttons: Shiwtch weapon
> Start: Pause
---
Wait a couple seconds after launching the game. If it doesn't boot, try checking
if your antivirus isn't misreporting the game as a threat.